from fastapi import FastAPI, __version__
from .api4ai import router as api4ai_router
from .tesseract import router as tesseract_router
from .config import settings

app = FastAPI(
    title="SigplacOCR",
    version=__version__,
    description="OCR API ",
    openapi_tags=[
        {
            "name": "API4AI Integration",
            "description": "Integration with external API4AI OCR service"
        },
        {
            "name": "Tesseract OCR",
            "description": "Local Tesseract OCR processing"
        }
    ]
)

app.include_router(api4ai_router)
app.include_router(tesseract_router)

@app.get("/health")
def health_check():
    return {
        "status": "OK",
        "version": __version__,
        "tesseract": settings.TESSERACT_PATH,
        "active_languages": settings.TESSERACT_LANG
    }