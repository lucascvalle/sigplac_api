from fastapi import APIRouter, HTTPException
import requests
from .config import settings

router = APIRouter(
    prefix="/api4ai",
    tags=["API4AI Integration"],
    responses={404: {"description": "Not found"}}
)


@router.post("/ocr")
async def process_image(image_url: str):
    """
    Processa uma imagem através do serviço OCR premium da API4AI.

    Args:
        image_url (str): URL pública da imagem a ser processada.

    Returns:
        dict: Resposta JSON da API4AI com resultados do OCR.

    Raises:
        HTTPException:
            - 500: Erro de comunicação com a API4AI ou erro interno.

    Exemplo:
        >> POST /api4ai/ocr?image_url=https://exemplo.com/imagem.png
        {
            "results": [
                {
                    "text": "Texto extraído...",
                    "confidence": 0.98
                }
            ]
        }
    """
    try:
        response = requests.post(
            'https://ocr43.p.rapidapi.com/v1/results',
            headers={
                'Content-Type': 'application/x-www-form-urlencoded',
                'x-rapidapi-host': settings.API4AI_HOST,
                'x-rapidapi-key': settings.API4AI_KEY.get_secret_value()
            },
            data={'url': image_url},
            timeout=15
        )
        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=500,
            detail=f"API communication error: {str(e)}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {str(e)}"
        )

