from fastapi import APIRouter, HTTPException, Query
import requests
from PIL import Image
from io import BytesIO
import pytesseract

router = APIRouter(
    prefix="/tesseract",
    tags=["Tesseract OCR"],
    responses={404: {"description": "Not found"}}
)


@router.post("/ocr")
def process_image(image_url: str = Query(..., description="URL da imagem para OCR")):
    """
    Processa uma imagem através do serviço OCR premium da API4AI.

    Args:
        image_url (str): URL pública da imagem a ser processada.

    Returns:
        dict: Resposta estruturada da API4AI contendo:
            - Metadados da imagem (dimensões, hash)
            - Texto extraído em formato hierárquico
            - Status do processamento

    Exemplo de Resposta:
        >> POST /api4ai/ocr?image_url=https://exemplo.com/hello-world.png
        {
            "results": [
                {
                    "status": {"code": "ok", "message": "Success"},
                    "name": "https://exemplo.com/hello-world.png",
                    "width": 1475,
                    "height": 1106,
                    "entities": [
                        {
                            "kind": "objects",
                            "name": "text",
                            "objects": [
                                {
                                    "box": [0.022, 0.066, 0.938, 0.902],
                                    "entities": [
                                        {
                                            "kind": "text",
                                            "text": "Hello World"
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    """
    try:
        # Baixa a imagem
        response = requests.get(image_url, timeout=10)
        response.raise_for_status()
        image = Image.open(BytesIO(response.content))

        # OCR simples (sem configs avançadas)
        text = pytesseract.image_to_string(image, lang='eng')

        return {
            "text": text.strip()
        }

    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Erro ao baixar imagem: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no processamento OCR: {str(e)}")
