import re
import logging
import requests
from typing import Optional, List
from ..config import settings
from ..exceptions import ValidationError

logger = logging.getLogger(__name__)


class PlacaValidator:
    def __init__(self):
        self.ocr_service_url = str(settings.OCR_SERVICE_URL).rstrip('/')
        self.timeout = settings.OCR_TIMEOUT

    def validate_placa_descartada(self, token: str, image_url: str) -> dict:
        """
        Valida se uma placa de veículo foi descartada (cortada) com base em uma imagem.

        Args:
            token: A string da placa a ser validada (formato XXX-YYYY para antiga, XXXXXXX para Mercosul).
            image_url: A URL da imagem a ser analisada.

        Returns:
            Um dicionário contendo o resultado da validação.
            - placa_descartada (bool|None): True se cortada, False se intacta, None se não encontrada.
            - motivo (str): Descrição do resultado.
            - ocr_global (str): O texto completo extraído pelo OCR.
            - tipo_placa (str): "ANTIGA" ou "MERCOSUL".
        """
        logger.info(f"Iniciando validação para token: {token} e imagem: {image_url}")
        try:
            ocr_data = self._get_ocr(image_url)
            ocr_text = self._extrair_texto_ocr(ocr_data)
            logger.info(f"Texto extraído do OCR: '{ocr_text}'")

            resultado_validacao = self._validar_placa_cortada(token, ocr_text)
            tipo_placa = "ANTIGA" if '-' in token else "MERCOSUL"

            if resultado_validacao is None:
                motivo = "Placa não encontrada na imagem"
            elif resultado_validacao:
                motivo = "Placa descartada (cortada)"
            else:
                motivo = "Placa não descartada (intacta)"

            logger.info(f"Resultado da validação: placa_descartada={resultado_validacao}, motivo='{motivo}'")

            return {
                "placa_descartada": resultado_validacao,
                "motivo": motivo,
                "ocr_global": ocr_text,
                "tipo_placa": tipo_placa
            }

        except ValidationError:
            raise  # Repassa a exceção de validação (ex: falha no OCR)
        except Exception as e:
            logger.error(f"Erro inesperado durante a validação da placa: {str(e)}")
            raise ValueError(f"Falha interna na validação: {str(e)}") from e

    def _get_ocr(self, image_url: str) -> dict:
        endpoint = f"{self.ocr_service_url}/api4ai/ocr"
        try:
            response = requests.post(
                endpoint,
                params={'image_url': image_url},
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Falha na requisição ao serviço de OCR: {str(e)}")
            raise ValidationError("Falha ao acessar serviço OCR") from e

    def _validar_placa_cortada(self, token_placa: str, ocr_texto: str) -> Optional[bool]:
        """
        Lógica principal para determinar se a placa está cortada, intacta ou não foi encontrada,
        seguindo a regra de negócio: primeiro procura inteira, depois em partes.
        """
        # Prepara os tokens do OCR e o token da placa (ground truth)
        texto_processado = ocr_texto.upper().replace("\n", " ").strip()
        tokens_ocr = set(t.replace("-", "") for t in texto_processado.split())
        token_placa_norm = token_placa.upper().strip().replace("-", "")

        logger.info(f"Iniciando validação. Ground Truth: '{token_placa_norm}'. Tokens OCR: {tokens_ocr}")

        # Etapa 1: Procurar a placa completa e intacta
        for ocr_token in tokens_ocr:
            if self._strings_match(ocr_token, token_placa_norm):
                logger.info(f"SUCESSO: Placa encontrada INTACTA. OCR: '{ocr_token}', Placa: '{token_placa_norm}'")
                return False  # False significa 'não descartada' (intacta)

        logger.info(f"Placa intacta não encontrada. Prosseguindo para verificação de corte.")

        # Etapa 2: Se não encontrou intacta, procurar por partes que indiquem um corte
        inicio_placa = token_placa_norm[:3]
        final_placa = token_placa_norm[3:]
        
        inicio_encontrado = any(self._strings_match(ocr_token, inicio_placa) for ocr_token in tokens_ocr)
        final_encontrado = any(self._strings_match(ocr_token, final_placa) for ocr_token in tokens_ocr)

        logger.info(f"Procurando partes. Início esperado: '{inicio_placa}' (encontrado: {inicio_encontrado}). Final esperado: '{final_placa}' (encontrado: {final_encontrado}).")

        if inicio_encontrado and final_encontrado:
            logger.info(f"SUCESSO: Placa encontrada CORTADA. Ambas as partes ('{inicio_placa}' e '{final_placa}') foram localizadas.")
            return True  # True significa 'descartada' (cortada)

        # Etapa 3: Se não encontrou nem intacta nem cortada, a placa não foi localizada
        logger.warning(f"FALHA: Placa não localizada. Nem a placa inteira nem as duas metades foram encontradas para o token '{token_placa_norm}'.")
        return None

    def _characters_are_equivalent(self, ocr_char: str, plate_char: str) -> bool:
        """
        Compara dois caracteres, considerando um conjunto de trocas comuns de OCR.
        Retorna True se forem idênticos ou equivalentes.
        """
        if ocr_char == plate_char:
            return True
        
        equivalences = [
            {'O', '0', 'Q'},
            {'I', '1'},
            {'S', '5'},
            {'Z', '2'},
            {'B', '8'},
            {'G', '6'},
            {'A', '4'}
        ]
        
        for group in equivalences:
            if ocr_char in group and plate_char in group:
                return True
        
        return False

    def _strings_match(self, ocr_str: str, plate_str: str) -> bool:
        """
        Verifica se a string do OCR corresponde à da placa, permitindo trocas de caracteres.
        Ambas as strings devem ter o mesmo comprimento.
        """
        if len(ocr_str) != len(plate_str):
            return False
        
        return all(self._characters_are_equivalent(c1, c2) for c1, c2 in zip(ocr_str, plate_str))

    def _extrair_texto_ocr(self, ocr_data: dict) -> str:
        """Extrai e concatena todo o texto detectado da resposta do serviço de OCR."""
        try:
            return self._extrair_texto_ocr_raw(ocr_data)
        except (KeyError, IndexError, TypeError) as e:
            logger.warning(f"Não foi possível extrair texto do OCR. Estrutura da resposta pode ter mudado. Erro: {e}")
            return ""

    def _extrair_texto_ocr_raw(self, ocr_data: dict) -> str:
        """Navega a estrutura de dados do OCR de forma segura para extrair o texto."""
        texto_total = []
        results = ocr_data.get('results', [])
        if not results:
            return ""

        for entity in results[0].get('entities', []):
            if entity.get('kind') == 'objects':
                for obj in entity.get('objects', []):
                    for ent_text in obj.get('entities', []):
                        if ent_text.get('kind') == 'text':
                            texto_total.append(ent_text.get('text', ''))
        
        return " ".join(texto_total).strip()