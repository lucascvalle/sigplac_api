from fastapi import APIRouter
from .schemas import PlacaDescartadaRequest, PlacaDescartadaResponse
from .services.placa_validator import PlacaValidator
from .services.moto_placa_validator import MotoPlacaValidator

router = APIRouter()
validator = PlacaValidator()
moto_validator = MotoPlacaValidator()

@router.post("/placa_descartada", response_model=PlacaDescartadaResponse)
async def validate_placa_descartada(request: PlacaDescartadaRequest):
    result = validator.validate_placa_descartada(
        token=request.token,
        image_url=request.image_url
    )
    return result

@router.post("/moto/placa_descartada", response_model=PlacaDescartadaResponse)
async def validate_moto_placa_descartada(request: PlacaDescartadaRequest):
    result = moto_validator.validate_placa_descartada(
        token=request.token,
        image_url=request.image_url
    )
    return result