# sigplac_validate/services/moto_placa_validator.py
import re
import logging
import requests
from ..config import settings
from ..exceptions import ValidationError

logger = logging.getLogger(__name__)


class MotoPlacaValidator:
    _EQUIVALENCES = [
        {'O', '0', 'Q'},
        {'I', '1'},
        {'S', '5'},
        {'Z', '2'},
        {'B', '8'},
        {'G', '6'},
        {'A', '4'}
    ]

    def __init__(self):
        self.ocr_service_url = str(settings.OCR_SERVICE_URL).rstrip('/')
        self.timeout = settings.OCR_TIMEOUT

    def validate_placa_descartada(self, token: str, image_url: str) -> dict:
        logger.info(f"Iniciando validação de moto para token: {token} e imagem: {image_url}")
        try:
            # Obter OCR da imagem completa
            ocr_data = self._get_ocr(image_url)
            texto_ocr = self._extrair_texto_ocr(ocr_data)
            logger.info(f"Texto extraído do OCR: '{texto_ocr}'")

            # Normalizar token (remover espaços, hífens e converter para maiúsculas)
            token_limpo = token.upper().replace(" ", "").replace("-", "")

            # Validar comprimento do token
            if len(token_limpo) != 7:
                raise ValidationError(f"Token de placa de moto deve ter 7 caracteres: {token}")

            # Dividir token em início e fim
            inicio_token = token_limpo[:3]
            fim_token = token_limpo[3:]

            # Determinar tipo da placa baseado no segundo caractere do fim_token
            if fim_token[1].isalpha():
                tipo_placa = "MERCOSUL"
            else:
                tipo_placa = "ANTIGA"

            # Verificar se a placa está descartada (cortada)
            placa_descartada = self._validar_placa_cortada(texto_ocr, inicio_token, fim_token)

            motivo = "Placa descartada (cortada)" if placa_descartada else "Placa não descartada (intacta)"

            logger.info(f"Resultado da validação de moto: placa_descartada={placa_descartada}, motivo='{motivo}'")

            return {
                "placa_descartada": placa_descartada,
                "motivo": motivo,
                "ocr_global": texto_ocr,
                "tipo_placa": tipo_placa
            }
        except Exception as e:
            raise ValidationError(f"Validation failed: {str(e)}") from e

    def _validar_placa_cortada(self, texto_ocr: str, inicio_token: str, fim_token: str) -> bool:
        """
        Verifica se a placa está cortada analisando a integridade dos tokens no texto OCR

        Retorna True se a placa está descartada (cortada)
        Retorna False se a placa está intacta
        """
        # Verificar se o início_token aparece como bloco contínuo
        inicio_intacto = self._token_intacto_no_texto(inicio_token, texto_ocr)

        # Verificar se o fim_token aparece como bloco contínuo
        fim_intacto = self._token_intacto_no_texto(fim_token, texto_ocr)

        # Se ambos tokens aparecerem como blocos contínuos, a placa está intacta
        # Se qualquer um estiver fragmentado, a placa foi cortada
        return not (inicio_intacto and fim_intacto)

    def _token_intacto_no_texto(self, token: str, texto: str) -> bool:
        """
        Verifica se o token aparece como um bloco contínuo no texto, sem fragmentação

        Exemplos:
          token "ABC" em "123 ABC 456" -> intacto (True)
          token "ABC" em "A B C 123"   -> fragmentado (False)
        """
        # Criar padrão regex que busca o token como sequência contínua
        pattern_parts = []
        for char_token in token:
            found_equivalence = False
            for group in self._EQUIVALENCES:
                if char_token.upper() in group:
                    # Se o caractere do token está em um grupo de equivalência, cria um grupo regex
                    pattern_parts.append(f"[{''.join(list(group))}]")
                    found_equivalence = True
                    break
            if not found_equivalence:
                # Se não encontrou equivalência, usa o próprio caractere (escapado para regex)
                pattern_parts.append(re.escape(char_token))

        pattern = "".join(pattern_parts)

        # Procurar o padrão no texto
        match = re.search(pattern, texto, re.IGNORECASE)

        # Se encontrou uma correspondência, verificar se está intacta
        if match:
            matched_text = match.group(0)
            # Verificar se o texto correspondente tem o mesmo comprimento do token
            # sem espaços ou caracteres adicionais
            return len(matched_text) == len(token)

        return False

    def _get_ocr(self, image_url: str) -> dict:
        endpoint = f"{self.ocr_service_url}/api4ai/ocr"
        try:
            response = requests.post(
                endpoint,
                params={'image_url': image_url},
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"OCR request failed: {str(e)}")
            raise ValidationError("Falha ao acessar serviço OCR") from e

    def _extrair_texto_ocr(self, ocr_data: dict) -> str:
        try:
            return self._extrair_texto_ocr_raw(ocr_data)
        except:
            return "Erro ao extrair texto OCR"

    def _extrair_texto_ocr_raw(self, ocr_data: dict) -> str:
        texto = ""
        for result in ocr_data.get('results', []):
            for entity in result.get('entities', []):
                if entity.get('kind') == 'objects':
                    for obj in entity.get('objects', []):
                        for ent in obj.get('entities', []):
                            if ent.get('kind') == 'text':
                                texto += ent.get('text', '') + " "
        return texto.strip()