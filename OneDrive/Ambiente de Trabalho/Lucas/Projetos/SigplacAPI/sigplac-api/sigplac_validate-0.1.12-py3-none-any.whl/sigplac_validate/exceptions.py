class ValidationError(Exception):
    """Exceção para erros de validação"""
    pass

class OCRServiceError(Exception):
    """Exceção para erros no serviço OCR"""
    pass

class ImageProcessingError(Exception):
    """Exceção para erros no processamento de imagem"""
    pass