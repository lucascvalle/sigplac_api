from fastapi import FastAPI, __version__, Request
from .api import router as validate_router
from .config import settings
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger("uvicorn.access")
logger.handlers = []  # Remove handlers padrão do Uvicorn

app = FastAPI(
    title="Sigplac Validate",
    version=__version__,
    description="Endpoints de validação de documentos usando OCR",
    openapi_tags=[
        {"name": "Validate", "description": "Validações específicas"}
    ]
)


# Configuração personalizada de logging para o Uvicorn
@app.middleware("http")
async def log_requests(request, call_next):
    # Sanitizar URLs com image_url
    query_params = request.query_params
    sanitized_url = str(request.url)

    if "image_url" in query_params:
        image_url = query_params["image_url"]

        # Reduzir logs de data URLs
        if image_url.startswith("data:image/"):
            sanitized_url = f"{request.url.path}?image_url=[DATA_URL]"
        else:
            # Mostrar apenas domínio para URLs externas
            from urllib.parse import urlparse
            parsed = urlparse(image_url)
            domain = parsed.netloc if parsed.netloc else "local"
            sanitized_url = f"{request.url.path}?image_url=...{domain}"

    logger.info(f"{request.method} {sanitized_url}")
    response = await call_next(request)
    return response


# Inclui apenas as rotas de validação
app.include_router(validate_router)

@app.get("/health")
def health_check():
    return {
        "status": "OK",
        "version": __version__,
        "ocr_service_url": settings.OCR_SERVICE_URL
    }