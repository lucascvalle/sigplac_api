from fastapi import APIRouter
from .schemas import PlacaDescartadaRequest, PlacaDescartadaResponse
from .services.placa_validator import PlacaValidator

router = APIRouter()
validator = PlacaValidator()

@router.post("/placa_descartada", response_model=PlacaDescartadaResponse)
async def validate_placa_descartada(request: PlacaDescartadaRequest):
    result = validator.validate_placa_descartada(
        token=request.token,
        image_url=request.image_url
    )
    return result