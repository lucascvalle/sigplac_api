from fastapi import FastAPI
from sigplac_ocr.api4ai import router as api4ai_router
from sigplac_ocr.tesseract import router as tesseract_router
from sigplac_validate.api import router as validate_router

app = FastAPI(title="Sigplac Composed API")

# Rotas originais do sigplac_ocr
# Mantém /api4ai/ocr e /tesseract/ocr conforme empacotado
app.include_router(api4ai_router, prefix="/api4ai", tags=["API4AI Integration"])
app.include_router(tesseract_router, prefix="/tesseract", tags=["Tesseract OCR"])

# Rotas de validação
# Exemplo: POST /validate/placa_descartada/
app.include_router(validate_router, prefix="/validate", tags=["Validate"])
