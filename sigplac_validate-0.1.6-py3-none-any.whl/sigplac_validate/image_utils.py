import requests
from PIL import Image
from io import BytesIO
import base64
import logging
from typing import Tuple

logger = logging.getLogger(__name__)


def split_image_to_dataurls(image_url: str) -> Tuple[str, str]:
    """
    Divide a imagem em duas metades e retorna como data URLs formatadas

    Args:
        image_url: URL da imagem ou data URL

    Returns:
        Tuple contendo (data_url_metade_esquerda, data_url_metade_direita)

    Raises:
        ValueError: Se ocorrer erro no download ou processamento da imagem
    """
    try:
        # Log sanitizado
        if image_url.startswith('data:image/'):
            logger.info("Processing data URL image (content redacted in logs)")
            image_data = _decode_data_url(image_url)
            img = Image.open(BytesIO(image_data))
            max_half_size = (800, 600)  # Tamanho reduzido para metades
            img = _resize_and_orient_image(img, max_size=max_half_size)
            left_half, right_half = _split_image(img)
            return (
                _pil_to_data_url(left_half),
                _pil_to_data_url(right_half)
            )
        else:
            sanitized_url = image_url.split('?')[0]
            logger.info(f"Downloading image from: {sanitized_url}")
            response = requests.get(image_url, timeout=10)
            response.raise_for_status()
            img = Image.open(BytesIO(response.content))

        # Processamento da imagem
        img = _resize_and_orient_image(img)
        left_half, right_half = _split_image(img)

        return (
            _pil_to_data_url(left_half),
            _pil_to_data_url(right_half)
        )

    except Exception as e:
        logger.error(f"Image processing error: {str(e)}")
        raise ValueError(f"Image processing error: {str(e)}") from e


def _resize_and_orient_image(img: Image.Image, max_size: Tuple[int, int] = (1920, 1080)) -> Image.Image:
    """Redimensiona e orienta a imagem corretamente"""
    # Redimensiona se for muito grande
    if img.width > max_size[0] or img.height > max_size[1]:
        img.thumbnail(max_size, Image.LANCZOS)
        logger.info(f"Resized image to: {img.size}")

    # Corrige orientação se estiver vertical
    if img.height > img.width:
        logger.info("Rotating vertical image to landscape")
        img = img.rotate(90, expand=True)

    return img


def _split_image(img: Image.Image) -> Tuple[Image.Image, Image.Image]:
    """Divide a imagem em metades esquerda e direita"""
    width, height = img.size
    left_half = img.crop((0, 0, width // 2, height))
    right_half = img.crop((width // 2, 0, width, height))
    return left_half, right_half


def _decode_data_url(data_url: str) -> bytes:
    """Decodifica data URL para bytes da imagem"""
    try:
        header, encoded = data_url.split(",", 1)
        return base64.b64decode(encoded)
    except Exception as e:
        raise ValueError(f"Invalid data URL format: {str(e)}") from e


def _pil_to_data_url(image: Image.Image, format: str = "JPEG") -> str:
    """Converte imagem PIL para data URL com tamanho otimizado"""
    buffered = BytesIO()

    # Reduz qualidade e tamanho para metades
    quality = 75  # Reduzido de 85 para 75
    if format == "JPEG":
        image.save(buffered, format=format, quality=quality, optimize=True)
    else:
        image.save(buffered, format=format)

    img_str = base64.b64encode(buffered.getvalue()).decode()
    return f"data:image/{format.lower()};base64,{img_str}"