import os
from pydantic import AnyHttpUrl
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Configuração do serviço OCR
    OCR_SERVICE_URL: AnyHttpUrl = os.getenv("OCR_SERVICE_URL", "http://localhost:8000")
    OCR_TIMEOUT: int = int(os.getenv("OCR_TIMEOUT", 10))

    # Configuração do próprio serviço
    APP_PORT: int = int(os.getenv("APP_PORT", 5000))
    APP_HOST: str = os.getenv("APP_HOST", "0.0.0.0")
    APP_RELOAD: bool = os.getenv("APP_RELOAD", "false").lower() == "true"

    class Config:
        case_sensitive = True
        env_file = ".env"


settings = Settings()