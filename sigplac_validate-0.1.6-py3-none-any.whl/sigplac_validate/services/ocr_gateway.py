import requests
from ..config import settings
from ..exceptions import OCRServiceError
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


class OCRGateway:
    def __init__(self):
        self.base_url = str(settings.OCR_SERVICE_URL).rstrip('/')
        self.timeout = settings.OCR_TIMEOUT

    def get_ocr(self, image_url: str) -> str:
        """Obtém texto OCR para uma imagem sanitizando logs"""
        endpoint = f"{self.base_url}/api4ai/ocr"

        try:
            # Log sanitizado para qualquer tipo de URL
            sanitized_url = self._sanitize_url_for_logging(image_url)
            logger.info(f"Making OCR request for image: {sanitized_url}")

            response = requests.post(
                endpoint,
                params={'image_url': image_url},
                timeout=self.timeout
            )

            # Verificar status code antes de processar
            if response.status_code != 200:
                error_msg = f"OCR service returned {response.status_code}"
                logger.error(error_msg)
                raise OCRServiceError(error_msg)

            return response.text

        except requests.exceptions.RequestException as e:
            sanitized_error = str(e).split('for url:')[0]  # Remove a URL do erro
            logger.error(f"OCR request failed: {sanitized_error}")
            raise OCRServiceError(f"OCR request failed: {sanitized_error}")

    def _sanitize_url_for_logging(self, url: str) -> str:
        """Sanitiza URLs para logging removendo dados sensíveis"""
        if url.startswith('data:image/'):
            return "[DATA_URL_REDACTED]"

        try:
            parsed = urlparse(url)
            if parsed.netloc:
                return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            return f"[LOCAL_URL]{parsed.path}"
        except:
            return "[MALFORMED_URL]"

    def get_ocr_from_bytes(self, image_bytes: bytes) -> str:
        """Alternativa para enviar imagem direto (não usado neste caso)"""
        # Implementação similar usando multipart/form-data
        pass