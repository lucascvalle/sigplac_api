import re
import logging
import requests
from ..config import settings
from ..exceptions import ValidationError

logger = logging.getLogger(__name__)


class PlacaValidator:
    def __init__(self):
        self.ocr_service_url = str(settings.OCR_SERVICE_URL).rstrip('/')
        self.timeout = settings.OCR_TIMEOUT

    def validate_placa_descartada(self, token: str, image_url: str) -> dict:
        try:
            # Obter OCR da imagem completa
            ocr_data = self._get_ocr(image_url)

            # Validar placa
            placa_descartada = self._validar_placa_cortada(token, ocr_data)
            tipo_placa = "ANTIGA" if '-' in token else "MERCOSUL"

            motivo = "Placa descartada (cortada)" if placa_descartada else "Placa não descartada (intacta)"
            ocr_text = self._extrair_texto_ocr(ocr_data)

            return {
                "placa_descartada": placa_descartada,
                "motivo": motivo,
                "ocr_global": ocr_text,
                "tipo_placa": tipo_placa
            }

        except Exception as e:
            raise ValidationError(f"Validation failed: {str(e)}") from e

    def _get_ocr(self, image_url: str) -> dict:
        endpoint = f"{self.ocr_service_url}/api4ai/ocr"
        try:
            response = requests.post(
                endpoint,
                params={'image_url': image_url},
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"OCR request failed: {str(e)}")
            raise ValidationError("Falha ao acessar serviço OCR") from e

    def _validar_placa_cortada(self, token_placa: str, ocr_response: dict) -> bool:
        try:
            texto_raw = self._extrair_texto_ocr_raw(ocr_response)
        except (KeyError, IndexError):
            texto_raw = ""

        texto = texto_raw.replace("\n", " ").upper().strip()
        raw_tokens = texto.split()

        token_up = token_placa.upper().strip()
        eh_antiga = '-' in token_up
        token_sem_hifen = token_up.replace("-", "").replace("O", "0")

        # Caso especial ANTIGA: verificar formato XXX-YYYY
        if eh_antiga:
            for i, t in enumerate(raw_tokens):
                if t == "-" and i > 0 and i < len(raw_tokens) - 1:
                    prev = raw_tokens[i - 1]
                    nex = raw_tokens[i + 1]
                    if re.fullmatch(r"[A-Z]{3}", prev) and re.fullmatch(r"[0-9]{4}", nex):
                        if self._matches_token(prev + "-" + nex, token_up):
                            return False  # Placa intacta

        # Filtrar tokens relevantes
        possiveis = []
        for t in raw_tokens:
            # Antiga completa
            if re.fullmatch(r"[A-Z]{3}-[0-9]{4}", t):
                possiveis.append(t)
            # Mercosul completa
            elif not eh_antiga and re.fullmatch(r"[A-Z0-9]{7}", t):
                possiveis.append(t)
            # Início (3 letras)
            elif re.fullmatch(r"[A-Z]{3}", t):
                possiveis.append(t)
            # Final antiga (4 dígitos)
            elif re.fullmatch(r"[0-9]{4}", t):
                possiveis.append(t)
            # Final mercosul (4 alfanuméricos)
            elif not eh_antiga and re.fullmatch(r"[A-Z0-9]{4}", t):
                possiveis.append(t)

        partes = possiveis

        # Mercosul: duas partes = corte
        if not eh_antiga and len(partes) == 2:
            p1 = partes[0].replace("O", "0")
            p2 = partes[1].replace("O", "0")
            inicio, final = token_sem_hifen[:3], token_sem_hifen[3:]
            if (self._matches_token(inicio, p1) and
                    self._matches_token(final, p2)):
                return True

        # Token completo = não cortado
        for p in partes:
            p_norm = p.replace("O", "0")
            if eh_antiga:
                if re.fullmatch(r"[A-Z]{3}-[0-9]{4}", p_norm) and self._matches_token(token_up, p_norm):
                    return False
            else:
                if len(p_norm) == 7 and self._matches_token(token_sem_hifen, p_norm):
                    return False

        # Antiga: duas partes sem hífen = corte
        if eh_antiga and len(partes) == 2:
            p1 = partes[0].replace("O", "0")
            p2 = partes[1].replace("O", "0")
            inicio, final = token_up.split("-")
            if (self._matches_token(inicio, p1) and
                    self._matches_token(final, p2)):
                return True

        return False

    def _matches_token(self, token: str, candidate: str, max_mismatches: int = 1) -> bool:
        token = token.upper()
        candidate = candidate.upper()
        if len(token) != len(candidate):
            return False

        mismatches = 0
        for t_char, c_char in zip(token, candidate):
            if t_char.isdigit():
                if (c_char == t_char or
                        (t_char == '0' and c_char == 'O') or
                        (t_char == '1' and c_char == 'I')):
                    continue
                mismatches += 1
            else:
                if c_char == t_char:
                    continue
                mismatches += 1

            if mismatches > max_mismatches:
                return False

        return True

    def _extrair_texto_ocr(self, ocr_data: dict) -> str:
        try:
            return self._extrair_texto_ocr_raw(ocr_data)
        except:
            return "Erro ao extrair texto OCR"

    def _extrair_texto_ocr_raw(self, ocr_data: dict) -> str:
        texto = ""
        for result in ocr_data.get('results', []):
            for entity in result.get('entities', []):
                if entity.get('kind') == 'objects':
                    for obj in entity.get('objects', []):
                        for ent in obj.get('entities', []):
                            if ent.get('kind') == 'text':
                                texto += ent.get('text', '') + " "
        return texto.strip()