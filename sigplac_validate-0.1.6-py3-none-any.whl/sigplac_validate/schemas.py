from pydantic import BaseModel, Field
from typing import Optional

class PlacaDescartadaRequest(BaseModel):
    token: str
    image_url: str

class PlacaDescartadaResponse(BaseModel):
    placa_descartada: bool
    motivo: str
    ocr_global: str = Field(..., description="Texto reconhecido na imagem completa")
    tipo_placa: str