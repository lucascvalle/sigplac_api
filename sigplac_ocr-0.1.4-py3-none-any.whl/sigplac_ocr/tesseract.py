from fastapi import APIRouter, HTTPException, Query
import requests
from PIL import Image
from io import BytesIO
import pytesseract

router = APIRouter(
    prefix="/tesseract",
    tags=["Tesseract OCR"],
    responses={404: {"description": "Not found"}}
)


@router.post("/ocr")
def process_image(image_url: str = Query(..., description="URL da imagem para OCR")):
    """
    Realiza OCR básico em imagens usando Tesseract

    Args:
        image_url (str): URL pública de uma imagem com texto em inglês.

    Returns:
        dict: {"text": "Texto extraído"}

    Raises:
        HTTPException:
            - 400: URL inválida ou falha no download da imagem.
            - 500: Erro durante o processamento OCR.

    Exemplo:
        >> POST /tesseract/ocr?image_url=https://exemplo.com/hello-world.png
        {
            "text": "Hello World"
        }
    """

    try:
        # Baixa a imagem
        response = requests.get(image_url, timeout=10)
        response.raise_for_status()
        image = Image.open(BytesIO(response.content))

        # OCR simples (sem configs avançadas)
        text = pytesseract.image_to_string(image, lang='eng')

        return {
            "text": text.strip()
        }

    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Erro ao baixar imagem: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no processamento OCR: {str(e)}")
