from pydantic import SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Tesseract Configuration
    TESSERACT_PATH: str = '/usr/bin/tesseract'
    TESSERACT_LANG: str = 'eng'

    # API4AI Configuration
    API4AI_KEY: SecretStr
    API4AI_HOST: str = 'ocr43.p.rapidapi.com'

    # Validation
    @field_validator('TESSERACT_LANG')
    def validate_languages(cls, v):
        if not all(len(lang) == 3 for lang in v.split('+')):
            raise ValueError("Invalid language format. Use 3-letter ISO codes separated by '+'")
        return v

    model_config = SettingsConfigDict(
        env_file='.env',
        env_prefix='SIGPLAC_',
        case_sensitive=False
    )


settings = Settings()