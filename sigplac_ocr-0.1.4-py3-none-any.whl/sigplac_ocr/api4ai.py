from fastapi import APIRouter, HTTPException
import requests
from .config import settings

router = APIRouter(
    prefix="/api4ai",
    tags=["API4AI Integration"],
    responses={404: {"description": "Not found"}}
)


@router.post("/ocr")
async def process_image(image_url: str):
    """
    Processa uma imagem através do serviço OCR premium da API4AI.

    Args:
        image_url (str): URL pública da imagem a ser processada.

    Returns:
        dict: Resposta estruturada da API4AI contendo:
            - Metadados da imagem (dimensões, hash)
            - Texto extraído em formato hierárquico
            - Status do processamento

    Exemplo de Resposta:
        >> POST /api4ai/ocr?image_url=https://exemplo.com/hello-world.png
        {
            "results": [
                {
                    "status": {"code": "ok", "message": "Success"},
                    "name": "https://exemplo.com/hello-world.png",
                    "width": 1475,
                    "height": 1106,
                    "entities": [
                        {
                            "kind": "objects",
                            "name": "text",
                            "objects": [
                                {
                                    "box": [0.022, 0.066, 0.938, 0.902],
                                    "entities": [
                                        {
                                            "kind": "text",
                                            "text": "Hello World"
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    """
    try:
        response = requests.post(
            'https://ocr43.p.rapidapi.com/v1/results',
            headers={
                'Content-Type': 'application/x-www-form-urlencoded',
                'x-rapidapi-host': settings.API4AI_HOST,
                'x-rapidapi-key': settings.API4AI_KEY.get_secret_value()
            },
            data={'url': image_url},
            timeout=15
        )
        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=500,
            detail=f"API communication error: {str(e)}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {str(e)}"
        )

